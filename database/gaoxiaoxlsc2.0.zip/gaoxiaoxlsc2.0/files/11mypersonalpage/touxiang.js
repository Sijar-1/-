﻿
	var oDivu218 = document.getElementById('u218');
	  var oDivu218_img = document.getElementById('u218_img');
    var oDivu286 = document.getElementById('u286');
	var oDivu286_img = document.getElementById('u286_img');	
	var oDivu220 = document.getElementById('u220');
		
	oDivu218.style.height=oDivu218_img.offsetWidth/2+'px';
    oDivu286.style.top = (oDivu218.offsetHeight-oDivu286.offsetWidth/2)+ 'px';	
	 oDivu286.style.left =(oDivu218.offsetWidth-oDivu286_img.offsetWidth)/2+ 'px';	
	 oDivu220.style.marginTop=(oDivu286_img.offsetHeight)/2+20+ 'px';
